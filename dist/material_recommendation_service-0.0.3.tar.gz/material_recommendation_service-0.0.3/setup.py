#!/usr/bin/env python
# -*- coding:utf-8 -*-
from distutils.core import setup

setup(
      name='material_recommendation_service',
      version="0.0.3",
      author='yangxun',
      author_email="yangxun@chunyu.me",
      url='git@git.chunyu.me:yangxun/material_recommendation.git',
      description='物料推荐',
      long_description="",
      packages=['material_recommendation_service'],
)
